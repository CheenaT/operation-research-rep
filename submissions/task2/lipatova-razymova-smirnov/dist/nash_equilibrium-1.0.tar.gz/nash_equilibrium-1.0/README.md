# Nash Equilibrium

Simplex method implementation.
