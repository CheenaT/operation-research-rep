from setuptools import setup

setup(name='zakharovharazyanschegolev',
      version='0.1',
      description='matrix game',
      url='https://github.com/CheenaT/operation-research-rep/submissions/task2/zakharovharazyanschegolev',
      author='zladimir',
      author_email='zolodya@mail.ru',
      license='MIT',
      packages=['prog'],
      zip_safe=False)
